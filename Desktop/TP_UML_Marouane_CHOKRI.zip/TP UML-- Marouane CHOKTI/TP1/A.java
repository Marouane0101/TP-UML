public class A {

  public Integer R;

  public Integer Center;

  public String cle;

    public B A_B;
    public C A_C;

  public void perimetre() {
  }

  public void aire() {
  }

}