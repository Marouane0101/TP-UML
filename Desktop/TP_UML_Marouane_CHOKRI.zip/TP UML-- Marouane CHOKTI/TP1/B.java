public class B {

    public A A_B;
    public C B_C;

}