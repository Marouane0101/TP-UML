#ifndef B_h
#define B_h

class A;
class C;

class B {

 public:

    A *A_B;

    C *B_C;
};

#endif // B_h
