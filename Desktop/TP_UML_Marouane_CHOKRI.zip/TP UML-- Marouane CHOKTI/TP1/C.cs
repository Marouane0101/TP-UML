// FILE: C:/Users/user/Desktop/ESTO_2019_2020/Cours_IngLog//C.cs

using System.Collections;

// In this section you can add your own using directives
    // section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000964 begin
    // section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000964 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class C
{
    // Associations

     @element-type A
     */
    public A  A_C;

    /// <summary> 
    /// </summary>
    public ArrayList  B_C;
} /* end class C */
