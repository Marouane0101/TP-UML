import java.util.Vector;

public class C {

    /**
   * 
   * @element-type A
   */
  public Vector  A_C;
    public B B_C;

}