<?php

error_reporting(E_ALL);

/**
 * Model_test - class.B.php
 *
 * $Id$
 *
 * This file is part of Model_test.
 *
 * Automatically generated on 21.10.2019, 18:32:45 with ArgoUML PHP module 
 * (last revised $Date: 2010-01-12 20:14:42 +0100 (Tue, 12 Jan 2010) $)
 *
 * @author firstname and lastname of author, <author@example.org>
 */

if (0 > version_compare(PHP_VERSION, '5')) {
    die('This file was generated for PHP 5');
}

/**
 * include A
 *
 * @author firstname and lastname of author, <author@example.org>
 */
require_once('class.A.php');

/**
 * include C
 *
 * @author firstname and lastname of author, <author@example.org>
 */
require_once('class.C.php');

/* user defined includes */
// section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000963-includes begin
// section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000963-includes end

/* user defined constants */
// section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000963-constants begin
// section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000963-constants end

/**
 * Short description of class B
 *
 * @access public
 * @author firstname and lastname of author, <author@example.org>
 */
class B
{
    // --- ASSOCIATIONS ---
    // generateAssociationEnd :     // generateAssociationEnd : 

    // --- ATTRIBUTES ---

    // --- OPERATIONS ---

} /* end of class B */

?>