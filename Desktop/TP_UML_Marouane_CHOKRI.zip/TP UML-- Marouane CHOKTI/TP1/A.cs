// FILE: C:/Users/user/Desktop/ESTO_2019_2020/Cours_IngLog//A.cs

// In this section you can add your own using directives
    // section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000962 begin
    // section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000962 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class A
{
    // Attributes

    public Integer R;

    public Integer Center;

    public String cle;

    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  A_B;

    /// <summary> 
    /// </summary>
    public ArrayList  A_C;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void perimetre()
    {
    // section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000978 begin
    // section -64--88-56-1--4a651011:16d84887350:-8000:0000000000000978 end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void aire()
    {
    // section -64--88-56-1--4a651011:16d84887350:-8000:000000000000097A begin
    // section -64--88-56-1--4a651011:16d84887350:-8000:000000000000097A end

    }
} /* end class A */
