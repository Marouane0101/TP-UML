#ifndef C_h
#define C_h

class A;
class B;

class C {

 public:

    /**
     * @element-type A
     */
    A *A_C[ 2];

    B *B_C;
};

#endif // C_h
