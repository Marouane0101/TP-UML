#include<iostream>
#include<cstdlib>

using namespace std;
int main()
{   
    /// Tableau unidimentionnel 
    
  	 int taille=0;
    cout<<"Entrez la taille svp\n "<<endl;
    cin>>taille;
    system("cls");
	int *ptr = (int*) malloc(sizeof(int)*taille);
	int *ptr2 = (int*) malloc(sizeof(int)*taille);
	int *ptr3 = (int*) malloc(sizeof(int)*taille);
	cout<<"Remplissez le tableau 1\n"<<endl;
	for(int i=0;i<taille;i++)
	{
		cin>>*(ptr+i);
	}
	for(int i=0;i<taille;i++) cout<<*(ptr+i); getchar(); system("cls");
		cout<<"Remplissez le tableau 2\n"<<endl;
		for(int i=0;i<taille;i++)
	{
		cin>>*(ptr2+i);
	}
	for(int i=0;i<taille;i++) cout<<*(ptr2+i); getchar(); system("cls");
     system("color 0a");
	for(int i=0;i<taille;i++) *(ptr3+i)=*(ptr+i)+*(ptr2+i);
		cout<<"Leur Somme\n"<<endl;
	for(int i=0;i<taille;i++) cout<<*(ptr3+i);
	free(ptr); free(ptr2); free(ptr3);
	
	/// Tableau multidimentionnel 
	
	/*
	 int taille=0;
    cout<<"Entrez la taille svp \n"<<endl;
    cin>>taille;
    system("cls");
    	cout<<"Remplissez la matrice 1\n"<<endl;
	int **ptr = (int**) malloc(sizeof(int)*taille);
	for(int i=0;i<taille;i++)  *(ptr+i) = (int*) malloc(sizeof(int)*taille);
	
	for(int i=0;i<taille;i++) for(int j=0;j<taille;j++) cin>>*(*(ptr+i)+j);
	
    for(int i=0;i<taille;i++)
    {
    	for(int j=0;j<taille;j++) cout<<*(*(ptr+i)+j)<<" ";
    	cout<<"\n"<<endl;
	}
	getchar(); system("cls");
	     	cout<<"Remplissez la matrice 2\n"<<endl;

		int **ptr2 = (int**) malloc(sizeof(int)*taille);
	for(int i=0;i<taille;i++)  *(ptr2+i) = (int*) malloc(sizeof(int)*taille);
	
	for(int i=0;i<taille;i++) for(int j=0;j<taille;j++) cin>>*(*(ptr2+i)+j);
	
    for(int i=0;i<taille;i++)
    {
    	for(int j=0;j<taille;j++) cout<<*(*(ptr2+i)+j)<<" ";
    	cout<<"\n"<<endl;
	}
	getchar(); system("cls"); system("color 0a");
		cout<<"Leur Somme\n"<<endl;
		int **ptr3 = (int**) malloc(sizeof(int)*taille);
	for(int i=0;i<taille;i++)  *(ptr3+i) = (int*) malloc(sizeof(int)*taille);
	
	for(int i=0;i<taille;i++) for(int j=0;j<taille;j++) *(*(ptr3+i)+j)=*(*(ptr2+i)+j)+*(*(ptr+i)+j);
	
    for(int i=0;i<taille;i++)
    {
    	for(int j=0;j<taille;j++) cout<<*(*(ptr3+i)+j)<<" ";
    	cout<<"\n"<<endl;
	}
	free(ptr); free(ptr2); free(ptr3);
	
	*/

}
