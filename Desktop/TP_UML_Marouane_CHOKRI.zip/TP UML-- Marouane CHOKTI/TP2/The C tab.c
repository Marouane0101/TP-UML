#include<stdio.h>
#include<stdlib.h>
int main()
{
    int taille=0;
    printf("Entrez la taille svp"); scanf("%d",&taille); system("cls");
	int *ptr= (int*) malloc(sizeof(int)*taille);
	int *ptr2= (int*) malloc(sizeof(int)*taille);
	int i=0;
	printf("Remplissez le tableau 1\n");
	for( i=0;i<taille;i++) 
	{
		scanf("%d",ptr+i);
	}
	i=0;
	for( i=0;i<taille;i++) 
	{
		printf("%d\t",*(ptr+i));
	}
	getchar();
	system("cls");
	printf("Remplissez le tableau 2\n");
	for( i=0;i<taille;i++) 
	{
		scanf("%d",ptr2+i);
	}
	i=0;
	for( i=0;i<taille;i++) 
	{
		printf("%d\t",*(ptr2+i));
	}
	getchar();
	system("cls");
	system("color 0a");
	printf("Leur Somme\n\n");
	
	int *ptr3=(int*) malloc(sizeof(int)*taille);
		for( i=0;i<taille;i++) 
	{
		*(ptr3+i)=*(ptr+i)+*(ptr2+i);
	   	 printf("%d\t",*(ptr3+i));
	}
  free(ptr); free(ptr2); free(ptr3);
  /*
  int taille=0;
  int i=0,j=0;
  printf("entrez la taille\n"); scanf("%d",&taille);
  system("cls");
  int **ptr = (int**) malloc(sizeof(int)*taille);
  int **ptr2 = (int**) malloc(sizeof(int)*taille);
    for(i;i<taille;i++) *(ptr+i)=(int*) malloc(sizeof(int)*taille);
    for(i=0;i<taille;i++) *(ptr2+i)=(int*) malloc(sizeof(int)*taille);

  printf("Remplissez la matrice 1 \n");
  for(i=0;i<taille;i++)
  {
  	for(j=0;j<taille;j++) scanf("%d",&ptr[i][j]);
  }
  system("cls");
   for(i=0;i<taille;i++)
  {
  	for(j=0;j<taille;j++) printf("%d\t",*(*(ptr+i)+j));
  	printf("\n");
  }
  printf("Remplissez la matrice 2 \n");
  for(i=0;i<taille;i++)
  {
  	for(j=0;j<taille;j++) scanf("%d",&ptr2[i][j]);
  }
   system("cls");
   for(i=0;i<taille;i++)
  {
  	for(j=0;j<taille;j++) printf("%d\t",*(*(ptr2+i)+j));
  	printf("\n");
  }
  getchar();
  system("cls");
  system("color 0a");
  printf("Leur Somme \n\n");
    int **ptr3 = (int**) malloc(sizeof(int)*taille);
    for(i=0;i<taille;i++) *(ptr3+i)=(int*) malloc(sizeof(int)*taille);
  for(i=0;i<taille;i++)
  {  
  	for(j=0;j<taille;j++)
  	{
  		   *(*(ptr3+i)+j)=0;
		   *(*(ptr3+i)+j)=*(*(ptr+i)+j) + *(*(ptr2+i)+j);
	  }
  }
   for(i=0;i<taille;i++)
  {
  	for(j=0;j<taille;j++) printf("%d\t",*(*(ptr3+i)+j));
  	printf("\n");
  }
  free(ptr); free(ptr2); free(ptr3);*/
}
