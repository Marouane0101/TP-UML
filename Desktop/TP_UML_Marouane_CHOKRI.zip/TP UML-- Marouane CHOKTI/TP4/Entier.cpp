#include<iostream>

using namespace std;

public class Entier
{
	public int a;
	short int b;
	long int c;
	
	public int factorial(int a) 
	{
		if(a<2) return 1;
		else return factorial(a-1)*a;
	} 

	public boolean est_pair(int a)
	{
		if(a%2==0) return true;
		else return false;
	}

	public int nbDiv(int nombre)
	    {
	    	int n = 0;
	    	for(int candidat = 1 ; candidat <= nombre; candidat++)
	    		  if(nombre % candidat == 0)
	    		  	   n++;
	        return n;
	    }
	
	 public boolean est_premier(int nbr)
	 {
		 int reste;
		  boolean flag = true;
	
		  for(int i=2; i <= nbr/2; i++)
		  {
		     reste = nbr%i;
		             
		     if(reste == 0)
		     {
		        flag = false;
		        break;
		     }
		  }
	
		  if(flag)
		     return true;
		  else
		     return false;
	
		  }

	 
    int pgcd (int a , int b) {
    	int t=0;
    	int r=0;
     if ( b>a) {
            t = a;
            a = b;
            b = t;
     }
    do {
            r = a % b;
            a = b;
            b = r;
    } while(r !=0);
   return a ;
    }

    
    public  int Calcule_PPCM (int Nb1, int Nb2) {
	int Produit, Reste, PPCM;
		
	Produit = Nb1*Nb2;
	Reste   = Nb1%Nb2;
	while(Reste != 0){
	    Nb1 = Nb2;
	    Nb2 = Reste;
	    Reste = Nb1%Nb2;
        }
	PPCM = Produit/Nb2;
		
	return PPCM;		
    }  
 
    public boolean est_multiple_de(int a,int b)  
    {
    	if(a%b==0) return true;
    	else return false;
    }

	 public int somme(int a ,int b)
	 {
		 return a+b;
	 }

	 public int produit(int a , int b)
	 {
		 return a*b;
	 }

	 public int soustraction(int a, int b)
	 {
		 return a-b;
	 }
	
}
}
