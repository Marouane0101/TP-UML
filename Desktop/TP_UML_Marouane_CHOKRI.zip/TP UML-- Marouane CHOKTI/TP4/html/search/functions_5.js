var searchData=
[
  ['somme_18',['somme',['../class_forme_geometrique_1_1_entier.html#a7040f3ba62501b6628c7cfde7d4e3d77',1,'FormeGeometrique::Entier']]],
  ['soustraction_19',['soustraction',['../class_forme_geometrique_1_1_entier.html#afad71018c2281ff7964f23255edf48aa',1,'FormeGeometrique::Entier']]]
];
