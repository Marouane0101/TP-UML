package FormeGeometrique;

public class Entier {
	/**
	 * @author Marwan
	 * @category  METHODES MATHEMATIQUES
	 * 
	 * 
	 */c
	int a ; 
	short b;
	long c;
/**
 * 
 * @param a
 * @param b
 * @param c
 * 
 */
	public int factorial(int a) 
	{
		if(a<2) return 1;
		else return factorial(a-1)*a;
	} 
	/**
	 * 
	 * @param factorial
	 * @return int a
	 */
	public boolean est_pair(int a)
	{
		if(a%2==0) return true;
		else return false;
	}
	/**
	 * 
	 * @param est_pair
	 * @return int a
	 */
	
	public int nbDiv(int nombre)
	    {
	    	int n = 0;
	    	for(int candidat = 1 ; candidat <= nombre; candidat++)
	    		  if(nombre % candidat == 0)
	    		  	   n++;
	        return n;
	    }
	/**
	 * 
	 * @param nbDiv
	 * @return int nombre
	 */
	
	 public boolean est_premier(int nbr)
	 {
		 int reste;
		  boolean flag = true;
	
		  for(int i=2; i <= nbr/2; i++)
		  {
		     reste = nbr%i;
		             
		     if(reste == 0)
		     {
		        flag = false;
		        break;
		     }
		  }
		  /**
			 * 
			 * @param est_premier
			 * @return int nbr
			 */
		  if(flag)
		     return true;
		  else
		     return false;
	
		  }

	 
    int pgcd (int a , int b) {
    	int t=0;
    	int r=0;
     if ( b>a) {
            t = a;
            a = b;
            b = t;
     }
    do {
            r = a % b;
            a = b;
            b = r;
    } while(r !=0);
   return a ;
    }
    /**
	 * 
	 * @param pgcd
	 * @return int a , b
	 */
    
    public  int Calcule_PPCM (int Nb1, int Nb2) {
	int Produit, Reste, PPCM;
		
	Produit = Nb1*Nb2;
	Reste   = Nb1%Nb2;
	while(Reste != 0){
	    Nb1 = Nb2;
	    Nb2 = Reste;
	    Reste = Nb1%Nb2;
        }
	PPCM = Produit/Nb2;
		
	return PPCM;		
    }  
    /**
	 * 
	 * @param ppcm
	 * @return int nb1 , nb2
	 */
    public boolean est_multiple_de(int a,int b)  //
    {
    	if(a%b==0) return true;
    	else return false;
    }
    /**
	 * 
	 * @param est_multiple_de
	 * @return int a , b
	 */
	 public int somme(int a ,int b)
	 {
		 return a+b;
	 }
	    /**
		 * 
		 * @param somme
		 * @return int a , b
		 */
	 public int produit(int a , int b)
	 {
		 return a*b;
	 }
	    /**
		 * 
		 * @param produit
		 * @return int a , b
		 */
	 public int soustraction(int a, int b)
	 {
		 return a-b;
	 }
	    /**
		 * 
		 * @param soustraction
		 * @return int a , b
		 */
}
